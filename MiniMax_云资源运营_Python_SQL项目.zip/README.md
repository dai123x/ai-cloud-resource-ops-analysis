# Cloud Resource Utilization & Cost Analysis

A portfolio project for **AI/cloud resource operations**. It uses synthetic GPU/CPU usage and cost data to demonstrate an end-to-end workflow:

**SQL extraction → Python/pandas analysis → idle-resource detection → cost analysis → capacity recommendation → operations report**

## Why this project
AI infrastructure operations needs visibility into utilization, cost, and demand. FinOps practice similarly connects usage/cost data with optimization and planning. Kubernetes exposes GPUs as schedulable extended resources such as `nvidia.com/gpu`.

## Tech stack
- Python 3
- pandas / NumPy
- SQL / SQLite
- Optional next step: Docker + Kubernetes metrics

## Dataset
`data/resource_usage.csv` contains 56 days of synthetic resource records:
- team / instance / GPU type
- allocated GPU
- GPU utilization
- CPU allocation / utilization
- runtime
- hourly GPU price
- cost

**All data are synthetic. No company-internal data are used.**

## Run
```bash
python src/analyze.py
```

## SQL skills demonstrated
- GROUP BY / aggregation
- filtering
- CTE
- window functions
- cost and utilization metrics

## Outputs
- `output/team_summary.csv`
- `output/capacity_forecast.csv`

## Interview story
1. Build a unified resource-usage table.
2. Measure utilization and cost by team.
3. Flag persistently low-utilization resources.
4. Estimate potential idle cost instead of blindly downsizing.
5. Use recent demand plus a safety buffer for a transparent capacity recommendation.
6. In production, add SLA/latency, GPU memory, queue time, Kubernetes requests/limits, and real billing data before making rightsizing decisions.

## Next iterations
- ingest Kubernetes/Prometheus metrics
- add GPU memory and P95 load
- anomaly alerts
- Dockerize the analysis job
- dashboard in Grafana/Streamlit
